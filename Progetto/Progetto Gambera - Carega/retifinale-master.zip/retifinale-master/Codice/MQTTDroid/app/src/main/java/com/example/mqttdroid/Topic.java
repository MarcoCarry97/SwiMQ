package com.example.mqttdroid;

public class Topic
{
	public static final String POST="retilab/swim/post";
	public static final String ROUGH="retilab/swim/rough";
	public static final String SENSOR_1="retilab/swim/sensor1";
	public static final String SENSOR_2="retilab/swim/sensor2";
	public static final String FITBIT="retilab/swim/fitbit";
	public static final String NEW_TRAIN="retilab/swim/newTrain";
	public static final String OLD_TRAIN="retilab/swim/oldTrain";
	public static final String LOGIN="retilab/swim/login";
	public static final String SIGNUP="retilab/swim/signup";
	public static final String CREATE="retilab/swim/create";

}
