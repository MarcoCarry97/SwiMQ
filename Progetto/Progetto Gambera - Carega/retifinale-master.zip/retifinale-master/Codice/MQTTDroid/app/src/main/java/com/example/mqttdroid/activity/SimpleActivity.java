package com.example.mqttdroid.activity;

import android.support.v7.app.AppCompatActivity;

public abstract class SimpleActivity extends AppCompatActivity
{
    @Override
    protected void onResume()
    {
        super.onResume();
    }

    @Override
    protected void onPause()
    {
        super.onPause();
    }


}
